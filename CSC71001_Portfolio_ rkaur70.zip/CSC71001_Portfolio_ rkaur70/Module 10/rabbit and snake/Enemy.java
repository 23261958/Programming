import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Enemy eat player.
 * 
 * @Rajpreet kaur 
 *  30-01-2020
 *  image refernce <https://www.naturepl.com/stock-photo-corn-snake-pantherophis-guttatus--okeetee-breed-on-white-background-image01584960.html/>
 */
public class Enemy extends Actor
{
    public Enemy()
    {
    }

    /**
     * Act - do whatever the Enemy wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {
        move(3);// Move at a speed of 1       
        randomTurn();
        checkPlayer();
        checkEdge();
    }  

    /**
     * Method randomTurn
     *
     */
    public void randomTurn(){
        if(Greenfoot.getRandomNumber(100)<1){           //1% of time 
            turn(180);
        }
    }

    /**
     * Method checkPlayer
     *
     */
    public void checkPlayer(){
        if (isTouching(Player.class)){ //if enemy enemy touch player 
            removeTouching(Player.class);// remove player
            Greenfoot.playSound("playereat.wav"); // play sound after touching player(sound recorded by Rajpreet kaur)
            Greenfoot.stop();//stop game 

        }  
    }

    /**
     * Method checkEdge
     *
     */
    public void checkEdge(){ //  if enemy is at edge 
        if (isAtEdge()){
            turn(Greenfoot.getRandomNumber(180)-90);// turn at 90

        }
    }
}

