import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * User control player.
 * 
 * @Rajpreet kaur 
 * @30-01-2020
 * image refernce<http://www.allwhitebackground.com/images/3/3871.jpg/>
 */
public class Player extends Actor
{
    private int carrotsCollected; // declare a value to calculate carrots
    private String name;
    private double delta= 0.4;
    /**
     * Player Constructor
     *
     */
    public Player()
    {
        carrotsCollected=0;// assign it 0.......intialising 
        name="Sam";// name of player
    }

    /**
     * Act - do whatever the Player wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {
        move(2);// move at speed of 2
        checkTouchingCarrot();
        checkKeyPress();
        checkForEdge();
    }

    /**
     * Method checkForEdge
     *
     */
    public void checkForEdge(){
        if (isAtEdge()){ 
            turn(Greenfoot.getRandomNumber(90)-45);// turn between 90 and -45

        }
    }

    /**
     * Method checkKeyPress
     *
     */
    public void checkKeyPress()
    {
        if(Greenfoot.isKeyDown("left")){ // when left key press turning -2
            turn(-2) ;
        }
        if(Greenfoot.isKeyDown("right")){ //when right key is pressed turning 2 
            turn(2);
        }

    }

    
    /**
     * Method checkTouchingCarrot
     *
     */
    public void checkTouchingCarrot(){     
        if (isTouching(Carrot.class)){  // if player touch carrot 
            removeTouching(Carrot.class); // remove carrot
            carrotsCollected = carrotsCollected +1;
            Greenfoot.playSound("eat.wav"); // play sound after touching carrot(sound recorded by Rajpreet kaur)
        }

        if(carrotsCollected==3){ // if player touch  three carrot 
            //Greenfoot.stop();
            name="Winning Sam";  //player name will change to winning Sam 
            Greenfoot.playSound("winning.wav"); // play winning sound(sound recorded by Rajpreet kaur)
            Greenfoot.stop();// stop game 

        }
    }

    /**
     * Method getName
     *
     * @return The return value
     */
    public  String getName(){
        return name;
    }

    /**
     * Method getPoints
     *
     * @return how many stars have been collected 
     */
    public int getPoints()
    {
        return carrotsCollected;
    }

    public boolean atWorldEdge(){
        if(getY()<40|| getWorld().getHeight()-getY()<40)
            return true;
        if(getX()<20|| getWorld().getWidth()-getX()<20)
            return true;
        else
            return false;
    }

}

