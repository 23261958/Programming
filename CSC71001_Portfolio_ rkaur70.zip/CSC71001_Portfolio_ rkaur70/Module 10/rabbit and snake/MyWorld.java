import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Ghost World 
 * 
 * @Rajpreet kaur 
 * @30-01-2020
 * background image <https://imgur.com/gallery/iizF0pN/>
 */
public class MyWorld extends World
{
    private static final int MAX_CARROTS=10;
    private static final int MAX_ROWS=2;
    /**
     * Constructor for objects of class MyWorld.
     * 
     */
    public MyWorld()
    {    
        // Create a new world with 600x400 cells with a cell size of 1x1 pixels.
        super(811, 497, 1); 
        //score=0;
        setup();
        //prepare();

        //showScore();

    }

    public void  setup() //adding random object
    {
        for(int i=0;i<5; i++){
            addObject(new Carrot(1),Greenfoot.getRandomNumber(600),
                Greenfoot.getRandomNumber(400));
        }
        for(int i=0;i<5; i++){
            addObject(new Carrot(2),Greenfoot.getRandomNumber(600),
                Greenfoot.getRandomNumber(400));
        }
        for(int i=0;i<5; i++){
            addObject(new Carrot(3),Greenfoot.getRandomNumber(600),
                Greenfoot.getRandomNumber(400));
        }
        for(int i=0;i<5; i++){
            addObject(new Player(),Greenfoot.getRandomNumber(600),
                Greenfoot.getRandomNumber(400));
        }
        for(int i=0;i<3; i++){
            addObject(new Enemy(),Greenfoot.getRandomNumber(600),
                Greenfoot.getRandomNumber(400));
        }

        for(int i=0; i<10;i++){
            addObject(new Carrot(Greenfoot.getRandomNumber(2)+1),200+i*20,300);
        }
    }
}

    
    
