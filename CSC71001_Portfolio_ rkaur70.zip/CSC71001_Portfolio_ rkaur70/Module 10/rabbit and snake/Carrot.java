import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Our Carrot is just food
 * 
 * @Rajpreet kaur 
 * @30-01-2020
 */
public class Carrot extends Actor
{
    GreenfootImage image1 = new GreenfootImage("carrot.jpg");// image reference from <https://the.ismaili/ismaili/sites/ismaili/files/5365.jpg/>
    GreenfootImage image2 = new GreenfootImage("banana.jpg"); 
    GreenfootImage image3 = new GreenfootImage("stawberry.jpg");
    private int speed;
    public Carrot()
    {
        setImage(image1);
        setImage("carrot.jpg");
    }

    /**
     * Act - do whatever the Carrot wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {
        checkAtEdge();
        // if(getImage() == image1){
        // setImage(image2);
        // }else{
        // setImage(image1);
        // }
        move(speed);

    }

    /**
     * Carrot Constructor
     *
     * @param s A parameter
     */
    public Carrot(int s)
    {
        if(s==1){
            setImage(image1);
            speed=5;
        }else if(s==2)
        {
            setImage(image2);
            speed=2;
        }
        else 
        {
            setImage(image3);
            speed=1;
        }

    }

    /**
     * Method checkAtEdge
     *
     */
    public void checkAtEdge()
    {
        if(isAtEdge()){
            turn(Greenfoot.getRandomNumber(90)-45);

        }

    }
}

   