import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class box here.
 * 
 * @Rajpreet kaur 
 * @version (a version number or a date)
 */
public class Box extends Actor
{
    private double height;
    private double width;
    private double depth;
    public Box( double h, double w, double d)
    {
        height=h;
        width=w;
        depth=d;
    }
        
    /**
     * Act - do whatever the box wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {
        // Add your action code here.
    }  
    /**
     * get the voulme of this box
     */
    public double volume()
    {
        double vol;
        vol=height*width*depth;
        return vol;
        
    }
    /**
     * get the surfaceArea of this box
     */
    public double surfaceArea()
    {
        double surfA;
        surfA=2*(height*width)+2*(height*depth)+2*(width*depth);
        return surfA;
        
    }
}
