import greenfoot.*;

/**
 * This is a stick man. Make him run and jump.
 * 
 * @Rajpreet kaur
 * @05-12-2019
 */
public class Stickman extends Actor
{
    /**
     * Method act
     *
     */
    public void act()
    {
       
       move(Greenfoot.getRandomNumber(10)-5);//move at random speed 
       //move(2);
        //checkKeyPress();
        moveIfSpace();
        checkForEdge();
    }
    // /**
     // * Method checkKeyPress
     // */
    // public void checkKeyPress() 
    // { 
        // if(Greenfoot.isKeyDown("space")){
            // move(4);}
        
    // }
    /**
     * Method moveIfSpace
     */
    public void moveIfSpace() //when space has pressed it will move to left
    { 
        if(Greenfoot.isKeyDown("space")){
             move(-4);
            }
        
    }
    /**
     * Method checkForEdge
     * 
     */
    public void checkForEdge(){  
            if(isAtEdge()){
            Greenfoot.stop();
            Greenfoot.playSound("stop.wav"); // play stop sound(sound recorded by Rajpreet kaur)
        }
    }
}

    