import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class MyWorld here.
 * 
 * @Rajpreet kaur 
 * @16-01-2020
 */
public class MyWorld extends World
{

    /**
     * Constructor for objects of class MyWorld.
     * 
     */
    public MyWorld()
    {    
        // Create a new world with 600x400 cells with a cell size of 1x1 pixels.
        super(600, 400, 1); 
        prepare();
    }

    public void prepare()
    {
        for(int j=0; j<2; j++){
            for(int i=0; i<16; i++){
                addObject(new Child(), i*40,15+ j*365);
            }

            for(int i=0; i<16; i++){
                addObject(new Child(), 10+j*580,15+i*40);
            }
        }
        for(int j=0; j<2; j++){
            for(int i=0; i<6; i++){
                addObject(new Child(), 150+j*300,120+i*35);
            }
        }
        for(int i=0; i<6; i++){
            addObject(new Child(), 445-i*30,120+i*35);
            addObject(new Child(), 150+i*29,120+i*35);
        }

    }
}




