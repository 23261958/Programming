import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Ghost World 
 * 
 *@Rajpreet kaur 
 * @20-01-2020
 * background image <https://imgur.com/gallery/iizF0pN/>
 */
public class MyWorld extends World
{
    private static final int MAX_CARROTS=10;
    private static final int MAX_ROWS=2;
    /**
     * Constructor for objects of class MyWorld.
     * 
     */
    public MyWorld()
    {    
        // Create a new world with 600x400 cells with a cell size of 1x1 pixels.
        super(811, 497, 1); 
        //score=0;
        
        prepare();
        
        //showScore();
       
    }

    // /**
     // * Method addScore
     // *
     // * @param points A parameter
     // */
    // public void addScore(int points)
    // {
        // score=score+points;
        // showScore();
        // if(score < 0)
        // {
            // showText("lose", 400,300);
            // Greenfoot.playSound("oops.wav");
            // Greenfoot.stop();
        // }
    //}
        // /**
         // * score will be on screen
         // */
        // private void showScore()
        // {
            // showText("Score:"+ score,80,25);
        // }
    /**
     * Prepare the world for the start of the program.
     * That is: create the initial objects and add them to the world.
     */
   
    private void prepare()
    {
        usingConstructors();
       
    }
    /**
     * Method usingConstructors
     *
     */
    public void usingConstructors()
    {
        for(int j=0; j<MAX_ROWS; j++){
            for(int i=0; i<MAX_CARROTS;i++){
                if(j==0){
                    addObject(new Carrot(1),100+(20*i),100+(100*j));
                }
                else{
                    addObject(new Carrot(2),100+(20*i),100+(100*j));
                }
                
            }
        }
        for(int i=0; i<10;i++){
            addObject(new Carrot(Greenfoot.getRandomNumber(2)+1),200+i*20,300);
        }
    }
}
    
   
    
    
    
    
    
    
    
    

