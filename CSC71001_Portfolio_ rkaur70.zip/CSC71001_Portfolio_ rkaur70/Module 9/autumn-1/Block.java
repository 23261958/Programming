import greenfoot.*;
import java.util.List;
/**
 * A block that bounces back and forth across the screen.
 * 
 * @author Rajpreet kaur
 * @version 0.1
 */
public class Block extends Actor
{
    private int delta = 2;

    /**
     * Move across the screen, bounce off edges. Turn leaves, if we touch any.
     */
    public void act() 
    {
        move();
        checkEdge();
        checkMouseClick();
    }

    /**
     * Move sideways, either left or right.
     */
    private void move()
    {
        setLocation(getX()+delta, getY());
    }

    /**
     * Check whether we are at the edge of the screen. If we are, turn around.
     */
    private void checkEdge()
    {
        if (isAtEdge()) 
        {
            delta = -delta;  // reverse direction
            World myWorld=getWorld();
            List<Apple>apples=myWorld.getObjects(Apple.class);
            for(Apple a:apples){
                a.turn(45);
            }
            List<Pear>pears= myWorld.getObjects(Pear.class);
            for(Pear p:pears){
                p.movePear();
            }
        }
    }

    /**
     * Check whether the mouse button was clicked. If it was, change all leaves.
     */
    private void checkMouseClick()
    {
        if (Greenfoot.mouseClicked(null)) 
        {
            World myWorld =getWorld();
            List<Leaf> leaves =myWorld.getObjects(Leaf.class);
            for(Leaf leaf:leaves){
                if(leaf.getX()<300){
                    leaf.changeImage();
                }
            }

        }
    }
 }

