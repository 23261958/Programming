import greenfoot.*;  
import java.util.List;
/**
 * User control player.
 * 
 *@Rajpreet kaur 
 * @24-01-2020
 * image refernce<http://www.allwhitebackground.com/images/3/3871.jpg/>
 */
public class Player extends Actor
{
    private int delta=3;

    public void act() 
    {
        movePlayer();
        checkCarrot();
        checkMouseClick();

    }

    public void movePlayer()
    {
        if(isAtEdge()){
            delta=-delta;
        }
        move(delta);
    }

    /**
     * Method checkCarrot
     *
     */
    public void checkCarrot(){
        if (isTouching(Carrot.class)){ //if player touch Carrot 
            removeTouching(Carrot.class);// remove Carrot
            Greenfoot.playSound("eat.wav"); // play sound after touching Carrot(sound recorded by Rajpreet kaur)
        }
    }

    /**
     * Check whether the mouse button was clicked. If it was, change all leaves.
     */
    private void checkMouseClick()
    {
        if (Greenfoot.mouseClicked(null)) 
        {
            World myWorld =getWorld();
            List<Carrot> carrots =myWorld.getObjects(Carrot.class);
            for(Carrot carrot:carrots){
                carrot.swapImage();
            }

        }
    }
}

    


 
