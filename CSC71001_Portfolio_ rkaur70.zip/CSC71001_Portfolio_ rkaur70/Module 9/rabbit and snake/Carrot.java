import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Our Carrot is just food
 * 
 * @Rajpreet kaur 
 * @24-01-2020
 */
public class Carrot extends Actor
{
    GreenfootImage image1 = new GreenfootImage("carrot.jpg");// image reference from <https://the.ismaili/ismaili/sites/ismaili/files/5365.jpg/>
    GreenfootImage image2 = new GreenfootImage("banana.jpg");  //image reference from <https://the.ismaili/ismaili/sites/ismaili/files/5365.jpg/>

    /**
     * Method act
     *
     */
    public void act()
    {
        swapImage();
    }

    public Carrot()
    {
        setImage(image1);
    }

    /**
     * Method swapImage
     *
     */
    public void swapImage() //carrot image swap with banana but they will show like twinkling
    {
        if(getImage() == image1){
            setImage(image2);
        }else{
            setImage(image1);
        }

    }
}

