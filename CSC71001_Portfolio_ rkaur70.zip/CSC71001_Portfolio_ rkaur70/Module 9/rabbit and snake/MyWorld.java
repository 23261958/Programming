import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Ghost World 
 * 
 * @Rajpreet kaur 
 * @24-01-2020
 * background image <https://imgur.com/gallery/iizF0pN/>
 */
public class MyWorld extends World
{
    private int score;

    /**
     * Constructor for objects of class MyWorld.
     * 
     */
    public MyWorld()
    {    
        // Create a new world with 600x400 cells with a cell size of 1x1 pixels.
        super(811, 497, 1); 
        setUp();
    }

    /**
     * Create the initial objects in the world.
     */
    private void setUp()
    {
        addObject(new Enemy(), 300, 200);
        prepare();
    }

    public void  prepare()//adding random object
    {
        for(int i=0;i<12; i++){
            addObject(new Carrot(),Greenfoot.getRandomNumber(600),
                Greenfoot.getRandomNumber(400));
        }
        for(int i=0;i<5; i++){
            addObject(new Player(),Greenfoot.getRandomNumber(600),
                Greenfoot.getRandomNumber(400));
        }
        for(int i=0;i<3; i++){
            addObject(new Enemy(),Greenfoot.getRandomNumber(600),
                Greenfoot.getRandomNumber(400));
        }
    }
}

        

    
    
    
