import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * MyCat is your own cat. Get it to do things by writing code in its act method.
 * 
 * @Rajpreet Kaur  
 * @14/11/2019
 */
public class MyCat extends Cat
{
    /**
     * Act - do whatever the MyCat wants to do.
     */
    public void act()
    {
       
        walkRight(2);// walk right
        sleep(1);
        if (Greenfoot.getRandomNumber(100)<90){
            shoutHooray();
        }
        //shouthooray
        if (Greenfoot.getRandomNumber(100)<90){
            dance();
        }
        if(isHungry()){ //to check  if cat is hungry
            eat();
            walkLeft(2);
            wait(40);
            sleep(1);
        }
        if(isAtEdge()){
            Greenfoot.stop();
        }
    }
}
    
    
    
    
    
    