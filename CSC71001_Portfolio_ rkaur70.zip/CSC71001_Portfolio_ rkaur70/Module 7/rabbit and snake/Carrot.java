import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Our Carrot is just food
 * 
 * @Rajpreet kaur 
 * @01-12-2019
 */
public class Carrot extends Actor
{
    GreenfootImage image1 = new GreenfootImage("carrotFood1.jpg");// image reference from <https://the.ismaili/ismaili/sites/ismaili/files/5365.jpg/>
    GreenfootImage image2 = new GreenfootImage("carrotFood2.jpg");  //image reference from <https://the.ismaili/ismaili/sites/ismaili/files/5365.jpg/>
    
    public Carrot()
    {
        setImage(image1);
        //setImage("carrotFood1.jpg");
    }

    /**
     * Act - do whatever the Carrot wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {
        if(getImage() == image1){
            setImage(image2);
        }else{
            setImage(image1);
        }
        
    }
}

   