import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Ghost World 
 * 
 * @Rajpreet kaur 
 * @16-01-2020
 * background image <https://imgur.com/gallery/iizF0pN/>
 */
public class MyWorld extends World
{
    private int score;

    /**
     * Constructor for objects of class MyWorld.
     * 
     */
    public MyWorld()
    {    
        // Create a new world with 600x400 cells with a cell size of 1x1 pixels.
        super(811, 497, 1);
        setup();
        score=0;

        prepare();

        //showScore();

    }

    public void addScore(int points)
    {
        score=score+points;
        showText("Score" + score,150,60);
        showScore();
        if(score < 0)
        {
            showText("lose", 400,300);
            Greenfoot.playSound("eat.wav");
            Greenfoot.stop();
        }
    }

    /**
     * score will be on screen
     */
    private void showScore()
    {
        showText("Score:"+ score,80,25);
    }

    /**
     * Prepare the world for the start of the program.
     * That is: create the initial objects and add them to the world.
     */

    private void prepare()
    {

        Player player1= new Player();//player is added to middle of screen
        addObject(player1,406,248);

    }

    private void setup()
    {
        int i = 0;
        while(i<10){
            addObject(new Carrot(),100+ (i*40),40);//in horizontal line carrot will be shown 
            i++;
        }
        i = 0;
        while(i<3){
            addObject(new Enemy(),660,(i*100)+40);// 3 enemy will be shown in vertical line
            i++;
        }
    }

}

    
    
