import greenfoot.*;

/**
 *  Rajpreet kaur
 * 10-12-2020
 * Worm. A sand worm. Very yummy. Especially crabs really like it.
 */
public class Worm extends Actor
{
    
}